# At least on Windows, Python seems to hook up the codecs on this
# import, so it's not enough to just package up all the encodings.
import encodings
