# Hook for _mysql, required if higher-level pure python module is not imported
# Author: htgoebel
# Date: 2011-11-18
# Ticket: #323

hiddenimports = ['_mysql_exceptions']
