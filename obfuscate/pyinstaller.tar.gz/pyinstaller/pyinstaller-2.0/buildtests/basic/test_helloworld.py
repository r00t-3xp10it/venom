#!/usr/bin/env python

print 'Hello Python!'
